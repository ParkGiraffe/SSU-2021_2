#include <iostream>
#include "Card.h"

using namespace std;

int main() {
    Card myCard;
    myCard.Flip();
    return 0;
}